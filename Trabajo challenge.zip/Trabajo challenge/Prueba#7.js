var numeros = [1, 4, 6, 7, 8, 8, 127,12, 89 ];

a = numeros [0]
b = numeros [1]
c = numeros [2]
d = numeros [3]
e = numeros [4]
f = numeros [5]
g = numeros [6]
h = numeros [7]
i = numeros [8]

console.log ([a,b,c],[d,e,f],[g,h,i])
console.log(numeros)
suma1 = [a+b+c];
suma2 = [d+e+f];
suma3 = [g+h+i];

resultado =[suma1,suma2,suma3];

resultado.reverse(); 

console.log(resultado)







