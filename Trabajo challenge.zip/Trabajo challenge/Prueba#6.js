


var letras = ['abc', 'ujk', 'zzy','ahj','aaz','oip'];

var a = 1;
var b = 2;
var c = 3;

letras[0] = 6 
letras[1] = 43
letras[2] = 80
letras[3] = 19
letras[4] = 29
letras[5] = 42
letras.sort(); 


console.log(letras)
