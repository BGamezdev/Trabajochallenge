<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "apirest";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn)
{
    die("no hay conexión: ".mysqli_connect_error());
}

$nombre = $_POST["email"];
$pass = $_POST["pass"];

$query = mysqli_query($conn,"SELECT * FROM login WHERE usuario = '".$nombre."' and password = '".$pass."'");
$nr = mysqli_num_rows($query);

if($nr == 1)
{
   header("Location: app.php");
    echo "bienvenido:" .$nombre;

}
else if ($nr == 0)
{
header("Location: #");

}
?>