
<html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous"><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
</html>
<?php

//$data = json_decode( file_get_contents('http://localhost:8080/api/trabajos'), true );



$option = array(
'http'=>array(
'method'=>"GET",
//'header'=>"Accept-language: en\r\n”.
"Cookie: foo=bar\r\n"
)
);
$ctx = stream_context_create($option);
$str_recurso = file_get_contents('http://localhost:8080/api/trabajos', false, $ctx);

$table = "<tr>
   <td><td>
   <td><td>
   <td><td>
<tr>";
print_r($str_recurso);

?>






