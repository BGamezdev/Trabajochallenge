package com.Trabajo.Trabajo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
