package com.Trabajo.Trabajo1.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity 
@Table(name = "Trabajo")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Trabajo {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Integer id;
private String usuario;
private String contraseña;
private String Bancos;
private String deuda;
private String couta;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getUsuario() {
	return usuario;
}
public void setUsuario(String usuario) {
	this.usuario = usuario;
}
public String getContraseña() {
	return contraseña;
}
public void setContraseña(String contraseña) {
	this.contraseña = contraseña;
}
public String getBancos() {
	return Bancos;
}
public void setBancos(String bancos) {
	Bancos = bancos;
}
public String getDeuda() {
	return deuda;
}
public void setDeuda(String deuda) {
	this.deuda = deuda;
}
public String getCouta() {
	return couta;
}
public void setCouta(String couta) {
	this.couta = couta;
}
@Override
public String toString() {
	return "Trabajo [id=" + id + ", usuario=" + usuario + ", contraseña=" + contraseña + ", Bancos=" + Bancos
			+ ", deuda=" + deuda + ", couta=" + couta + "]";
}



}