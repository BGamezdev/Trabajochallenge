package com.Trabajo.Trabajo1.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Trabajo.Trabajo1.model.Trabajo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Service
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class TrabajoService {
@Autowired
	private TrabajoRepository trabajoRepository;
	public void guardar (Trabajo trabajo) {
		trabajoRepository.save(trabajo);	
			}
	
	
	public List<Trabajo>obtenerTodos (){
		return trabajoRepository.findAll();
}	

	@SuppressWarnings("deprecation")
	public Trabajo obtenerTrabajo(Integer id) {
		return trabajoRepository.getOne(id);
		
}
	
	public void actualizar(Trabajo trabajo) {
		
		trabajoRepository.save(trabajo);
	}	
	public void eliminar(Integer id) {
		trabajoRepository.deleteById(id);
	}


}