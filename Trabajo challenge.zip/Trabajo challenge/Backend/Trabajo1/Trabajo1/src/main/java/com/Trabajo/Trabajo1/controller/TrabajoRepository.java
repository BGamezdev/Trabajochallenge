package com.Trabajo.Trabajo1.controller;
import org.springframework.stereotype.Repository;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.data.jpa.repository.JpaRepository;
import com.Trabajo.Trabajo1.model.Trabajo;

@SuppressWarnings("unused")
@Repository
public interface TrabajoRepository extends JpaRepository<Trabajo, Integer >{

	
}
